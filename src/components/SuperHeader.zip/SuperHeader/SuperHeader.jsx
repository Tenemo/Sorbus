import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './superHeader.scss';

const range = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

// eslint-disable-next-line react/prefer-stateless-function
export class SuperHeader extends Component {
    constructor(props) {
        super(props);
        this.state = {
            initialText: props.text,
            randomText: '',
            finalText: '',
        };
    }

    componentWillReceiveProps(props) {
        this.intervalId = setInterval(this.timer, 5);
        this.setState({
            randomText: '',
            finalText: '',
            initialText: props.text,
        });
    }

    componentWillUnmount() {
        clearInterval(this.intervalId);
    }

    timer = () => {
        const { initialText } = this.state;
        if (this.state.initialText.length > 0) {
            this.setState(
                {
                    randomText: (() =>
                        initialText
                            .split('')
                            .reduce(
                                newCombined =>
                                    newCombined.concat(
                                        range.charAt(
                                            Math.floor(
                                                Math.random() * range.length,
                                            ),
                                        ),
                                    ),
                                [],
                            ))(),
                },
                () => {
                    if (Math.random() < 0.05) {
                        this.setState(currentState => ({
                            finalText:
                                currentState.finalText +
                                currentState.initialText[0],
                            initialText: currentState.initialText.substr(1),
                        }));
                    }
                },
            );
        } else {
            clearInterval(this.intervalId);
            this.setState({ randomText: '' });
        }
    };

    render() {
        const { randomText, finalText } = this.state;
        return (
            <h2 className="superHeader">
                {finalText}
                {randomText}
            </h2>
        );
    }
}

SuperHeader.propTypes = {
    text: PropTypes.string.isRequired,
};

export default SuperHeader;
