import React, { Component } from 'react';
import PropTypes from 'prop-types';

import SuperHeader from '../SuperHeader';

function randomArrayElement(array) {
    return array[Math.floor(Math.random() * array.length)];
}

export class SuperSuperHeader extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentPhrase: props.words.reduce(
                (phrase, el) => phrase.concat(randomArrayElement(el)),
                [],
            ),
        };
    }

    componentWillMount() {
        const { phraseChangeSpeed } = this.props;
        this.intervalId = setInterval(this.timer, phraseChangeSpeed);
    }

    componentWillReceiveProps(props) {
        const { words } = props;
        this.setState({
            currentPhrase: words.reduce(
                (phrase, el) => phrase.concat(randomArrayElement(el)),
                [],
            ),
        });
    }

    componentWillUnmount() {
        clearInterval(this.intervalId);
    }

    timer = () => {
        const { currentPhrase } = this.state;
        const { words } = this.props;
        const randomIndex = Math.floor(Math.random() * currentPhrase.length);
        const newPhrase = currentPhrase;
        newPhrase[randomIndex] = randomArrayElement(words[randomIndex]);
        this.setState({
            currentPhrase: newPhrase,
        });
    };

    render() {
        const { currentPhrase } = this.state;
        const { rollSpeed } = this.props;
        return (
            <div className="superSuperHeader">
                {currentPhrase.map((word, i) => (
                    // eslint-disable-next-line react/no-array-index-key
                    <React.Fragment key={i}>
                        <SuperHeader rollSpeed={rollSpeed} text={word} />{' '}
                    </React.Fragment>
                ))}
            </div>
        );
    }
}

SuperSuperHeader.propTypes = {
    words: PropTypes.array,
    rollSpeed: PropTypes.number,
    phraseChangeSpeed: PropTypes.number,
};

SuperSuperHeader.defaultProps = {
    words: [
        ['AWESOME', 'INCREDIBLE', 'MEGA'],
        ['IMAGE', 'PICTURE', 'PHOTO'],
        ['UPLOADER', 'SENDER'],
    ],
    rollSpeed: 20,
    phraseChangeSpeed: 3000,
};

export default SuperSuperHeader;
